
┌┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┐
├┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┤
├─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┬─┤
│ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │
├─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┤
│ │ │ │ │ │ │ │ │ │U│.│S│.│ │G│R│A│P│H│I│C│S│ │C│O│M│P│A│N│Y│ │ │ │ │ │ │ │ │ │
├─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┼─┤
│ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │ │
├─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┴─┤
├─────────────────────────────────────────────────────────────────────────────┤
│                                 ~~ INFO ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ TYPEFACE     │ TX-02 Berkeley Mono™ Typeface Family                         │
│ VERSION      │ 2.002                                                        │
│ RELEASED ON  │ 2024-12-31                                                   │
│ TICKET No.   │ MLP74WZM                                                     │
│ BUILD DATE   │ 2025-08-09 06:07:57 UTC                                      │
│ FONT COUNT   │ 6 Fonts                                                      │
│ GLYPH COUNT  │ 3864 Glyphs                                                  │
│ BUILD TIME   │ 11.60 seconds                                                │
│ SERVICE No.  │ 20KX6KL56Y                                                   │
│ SERVICE      │ TS-024 Berkeley Mono™ Standard Compiler                      │
│ SERVICE TIER │ STANDARD                                                     │
│ LICENSE No.  │ JLKW-2XKN-JQ7M-K01Q                                          │
│ LICENSE      │ LT-02 Developer Font License                                 │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ FONTS ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ TX-02-742M   │ Light                                                        │
│ TX-02-744M   │ Light Oblique                                                │
│ TX-02-772M   │ Regular                                                      │
│ TX-02-774M   │ Oblique                                                      │
│ TX-02-7B2M   │ Bold                                                         │
│ TX-02-7B4M   │ Bold Oblique                                                 │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                         ~~ BUILD SPECIFICATIONS ~~                          │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ FC-001       │ 7                                                            │
│ FC-002       │ 47B                                                          │
│ FC-003       │ 24                                                           │
│ FC-004       │ zero.split                                                   │
│ FC-005       │ seven.standard                                               │
│ FC-008       │ on                                                           │
│ FC-010       │ desktop_otf                                                  │
│ FC-016       │ typeface_name                                                │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ FILES ~~                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│ BerkeleyMono-Light.otf                                                      │
│ BerkeleyMono-Light-Oblique.otf                                              │
│ BerkeleyMono-Regular.otf                                                    │
│ BerkeleyMono-Oblique.otf                                                    │
│ BerkeleyMono-Bold.otf                                                       │
│ BerkeleyMono-Bold-Oblique.otf                                               │
│ README.txt                                                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                         ~~ LOGS (2025-08-09 UTC) ~~                         │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ 06:07:45.824 │ INIT: Querying database for build ticket information         │
│ 06:07:45.826 │ INIT: Generated Package ID: 250809758QZ9XN42                 │
│ 06:07:45.827 │ INIT: Loading static font compiler                           │
│ 06:07:45.827 │ FEATURES: Processing FC-010: Set OTF format                  │
│ 06:07:45.927 │ FEATURES: Processing FC-008: Compile ligatures               │
│ 06:07:45.930 │ FEATURES: Processing FC-004: Target: zero, Source: zero.spli │
│ 06:07:45.930 │ FEATURES: Processing FC-005: Target: seven, Source: seven.st │
│ 06:07:47.799 │ INTERPOLATE: Light                                           │
│ 06:07:48.308 │ INTERPOLATE: LightOblique                                    │
│ 06:07:48.356 │ INTERPOLATE: Regular                                         │
│ 06:07:48.404 │ INTERPOLATE: Oblique                                         │
│ 06:07:48.453 │ INTERPOLATE: Bold                                            │
│ 06:07:48.500 │ INTERPOLATE: BoldOblique                                     │
│ 06:07:48.724 │ INTERPOLATE: Interpolating 6 instances                       │
│ 06:07:48.725 │ COMPILE: OTF, BerkeleyMono-Light                             │
│ 06:07:49.991 │ DISK IO: Saving BerkeleyMono-Light.otf to ramdisk            │
│ 06:07:50.092 │ COMPILE: OTF, BerkeleyMono-LightOblique                      │
│ 06:07:51.357 │ DISK IO: Saving BerkeleyMono-Light-Oblique.otf to ramdisk    │
│ 06:07:51.613 │ COMPILE: OTF, BerkeleyMono-Regular                           │
│ 06:07:52.875 │ DISK IO: Saving BerkeleyMono-Regular.otf to ramdisk          │
│ 06:07:52.976 │ COMPILE: OTF, BerkeleyMono-Oblique                           │
│ 06:07:54.401 │ DISK IO: Saving BerkeleyMono-Oblique.otf to ramdisk          │
│ 06:07:54.512 │ COMPILE: OTF, BerkeleyMono-Bold                              │
│ 06:07:55.775 │ DISK IO: Saving BerkeleyMono-Bold.otf to ramdisk             │
│ 06:07:55.877 │ COMPILE: OTF, BerkeleyMono-BoldOblique                       │
│ 06:07:57.315 │ DISK IO: Saving BerkeleyMono-Bold-Oblique.otf to ramdisk     │
│ 06:07:57.426 │ PACKAGE: Compressing font package 250809758QZ9XN42.zip       │
│ 06:07:57.426 │ PACKAGE: Uploading font package to AWS S3                    │
├──────────────┴──────────────────────────────────────────────────────────────┤
│                                ~~ LEGAL ~~                                  │
├──────────────┬──────────────────────────────────────────────────────────────┤
│ COPYRIGHT    │ Copyright 2022-2025. All Rights Reserved.                    │
│              │ Intellectual Property of U.S. Graphics, LLC.                 │
├─────────────────────────────────────────────────────────────────────────────┤
├┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┬┤
└┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┴┘